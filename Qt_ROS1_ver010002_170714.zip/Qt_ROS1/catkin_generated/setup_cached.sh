#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables
export CATKIN_TEST_RESULTS_DIR="/home/merg/catkin_ws/src/Qt_ROS1/test_results"
export ROS_TEST_RESULTS_DIR="/home/merg/catkin_ws/src/Qt_ROS1/test_results"

# modified environment variables
export CMAKE_PREFIX_PATH="/home/merg/catkin_ws/src/Qt_ROS1/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/merg/catkin_ws/src/Qt_ROS1/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/merg/catkin_ws/src/Qt_ROS1/devel/lib:/opt/ros/groovy/lib:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64/server:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64:/usr/lib/jvm/java-6-openjdk-amd64/jre/../lib/amd64"
export PATH="/home/merg/catkin_ws/src/Qt_ROS1/devel/bin:$PATH"
export PKG_CONFIG_PATH="/home/merg/catkin_ws/src/Qt_ROS1/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PWD="/home/merg/catkin_ws/src/Qt_ROS1"
export PYTHONPATH="/home/merg/catkin_ws/src/Qt_ROS1/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/merg/catkin_ws/src/Qt_ROS1/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/merg/catkin_ws/src/Qt_ROS1:$ROS_PACKAGE_PATH"