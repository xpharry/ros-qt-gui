#!/usr/bin/env zsh
# generated from catkin/cmake/templates/setup.zsh.in

CATKIN_SHELL=zsh
_CATKIN_SETUP_DIR=$(builtin cd "`dirname "$0"`" && pwd)
emulate sh # emulate POSIX
. "$_CATKIN_SETUP_DIR/setup.sh"
emulate zsh # back to zsh mode
